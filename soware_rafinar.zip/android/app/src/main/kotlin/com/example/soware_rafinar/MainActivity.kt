package com.example.soware_rafinar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
